package it.uniroma3.siw.silphspa.silphspa.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.silphspa.silphspa.model.Carrello;
import it.uniroma3.siw.silphspa.silphspa.model.Cliente;
import it.uniroma3.siw.silphspa.silphspa.model.Foto;
import it.uniroma3.siw.silphspa.silphspa.service.ClienteService;
import it.uniroma3.siw.silphspa.silphspa.service.ClienteValidator;
import it.uniroma3.siw.silphspa.silphspa.service.FotoService;

@Controller
public class ClienteController {
	
	@Autowired
	private ClienteService clienteService;
	@Autowired
	private ClienteValidator clienteValidator;
	@Autowired
	private FotoService fotoService;
	@RequestMapping( value = "/cliente", method = RequestMethod.POST)
	public String newCliente(@Valid @ModelAttribute("cliente") Cliente cliente, Model model, BindingResult bindingResult) {
		
		this.clienteValidator.validate(cliente, bindingResult);
		if(!bindingResult.hasErrors()) {
			//??
			this.clienteService.inserisci(cliente);
			model.addAttribute("clienti", this.clienteService.tutti());
			return "richiestaEffettuata.html";
		}
		else
			return "clienteForm.html";
	}
	//metodo che permette di rilanciare l'applicazione
		@RequestMapping("/addCliente")
		public String addCliente(Model model) {
			model.addAttribute("cliente", new Cliente());
			return "clienteForm.html";
		}
		
	//-----------------------------METODI DI RICERCA ------------------------------------------//
		@RequestMapping(value = "/ricercaFotografo", method= RequestMethod.GET)
		public String ricercaFotografo(@ModelAttribute("ricerca") Foto foto, Model model) {
			System.out.println(foto.getAutore());
			model.addAttribute("tutte", this.fotoService.fotoPerAutore(foto.getAutore()));
			return "home.html";
		}
		
		@RequestMapping(value = "/ricercaAlbum", method= RequestMethod.GET)
		public String ricercaAlbum(@ModelAttribute("ricerca") Foto foto, Model model) {
			model.addAttribute("tutte", this.fotoService.fotoPerAlbum(foto.getAlbum()));
			return "home.html";
		}
		
		@RequestMapping("/cercaFoto")
		public String ricercaFoto(Model model) {
			// To_do
			Foto foto = new Foto();
			model.addAttribute("ricerca", foto);
			return "ricerca.html";
		}
		@RequestMapping(value = "/aggiungi",params= {"addFoto"})
		public String aggiungiFoto(Model model, @ModelAttribute("carrello") Carrello carrello,@ModelAttribute("foto")Foto foto) {
			Cliente cliente = new Cliente();
			cliente.setCarrello(foto.getIndirizzo().toString());
			model.addAttribute("cliente", cliente);
			return "clienteForm.html";
		}
		
}
