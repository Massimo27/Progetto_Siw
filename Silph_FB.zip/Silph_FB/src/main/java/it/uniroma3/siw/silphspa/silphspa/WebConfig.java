/*package it.uniroma3.siw.silphspa.silphspa;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration @EnableWebMvc
public class WebConfig implements WebMvcConfigurer{
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler(
                "/css/**")
                .addResourceLocations(
                		"classpath:/static/css/"
                        );
		WebMvcConfigurer.super.addResourceHandlers(registry);
	}
	
	
}*/ //Con l'Accesso di FB il WebConfigurer per caricae il CSS va in contrasto con la richiesta Facebook'