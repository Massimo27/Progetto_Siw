package model;

public class Cliente {
	
	public String nome;
	public String cognome;
	public String email;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return ("<td>"+this.getNome()+"</td>"+"<td>"+this.getCognome()+"</td>"+"<td>"+this.getEmail()+"</td>");
	}
	@Override
	public boolean equals(Object obj) {
		Cliente cliente = (Cliente) obj;
		return this.nome== cliente.nome&&this.cognome==cliente.cognome;
	}
	@Override
	public int hashCode() {
		return this.nome.hashCode()+this.cognome.hashCode();
	}
}
