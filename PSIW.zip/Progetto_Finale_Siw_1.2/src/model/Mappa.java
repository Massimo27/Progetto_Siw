package model;

import java.io.FileOutputStream;
import java.util.*;

public final class Mappa {
	private static Set<Cliente> insiemeClienti;
	
	
	public static Set<Cliente> getinsiemeClienti() {
		return insiemeClienti;
	}

	public static void setinsiemeClienti(Set<Cliente> insiemeClienti) {
		Mappa.insiemeClienti = insiemeClienti;
	}
	
	public void addCliente(Cliente cliente) {
		if(!(insiemeClienti.add(cliente))) {
			System.out.println("Il Cliente e' gia' nel sistema");
		};
		
	}
}
